#!/bin/bash

cd /home/ctf/
timeout 25 ./file-v